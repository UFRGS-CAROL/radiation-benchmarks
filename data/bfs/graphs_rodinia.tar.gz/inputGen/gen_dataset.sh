#!/bin/bash

./graphgen 1024 1k
./graphgen 2048 2k
./graphgen 4096 4k
./graphgen 8192 8k
./graphgen 16384 16k
./graphgen 32768 32k
./graphgen 65536 64k
./graphgen 131072 128k
./graphgen 261444 256k
./graphgen 524288 512k
./graphgen 1048576 1M
./graphgen 2097152 2M
./graphgen 4194304 4M
./graphgen 8388608 8M
./graphgen 16777216 16M

